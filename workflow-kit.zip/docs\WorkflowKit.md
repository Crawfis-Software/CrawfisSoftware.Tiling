# Workflow kit (NuGet + Release assets + optional Unity UPM)

This repo contains a reusable GitHub Actions setup to:

- build + pack a .NET library into NuGet artifacts (`.nupkg` + `.snupkg`)
- optionally create a Unity Package Manager (UPM) tarball (`.tgz`) if a Unity package folder exists
- publish NuGet packages to nuget.org using OIDC (`NuGet/login@v1`)
- attach artifacts to the GitHub Release

## What to copy to another repository

Copy these files and folders into the target repo root:

- `.github/workflows/package.yml`
- `.github/workflows/release-please.yml`
- `.github/workflows/commitlint.yml`
- `.release-please-config.json`
- `.release-please-manifest.json`
- `commitlint.config.cjs`

## Minimal repo-specific edits

Edit `.github/workflows/package.yml` and update the top-level `env` values:

- `DOTNET_PROJECT`: path to the `.csproj` to pack (keep repos uniform if you can)
- `UPM_PACKAGE_ID`: e.g. `com.yourcompany.yourlib`
- `UPM_PACKAGE_DIR`: e.g. `Packages/com.yourcompany.yourlib`

If a repo has **no Unity package**, you can leave the UPM values alone; the workflow will just print a skip message.

## Required GitHub settings

### Secrets

- `NUGET_USER`: username/email used by `NuGet/login@v1` to mint a temporary API key via OIDC

### Environment

- Create an environment named `release` (used by the `publish-nuget` job)

## Expected repo structure (recommended)

- `<RepoRoot>/<YourLibrary>.csproj`
- Optional Unity UPM folder: `Packages/<UPM_PACKAGE_ID>/package.json`

## Creating a �drop-in zip�

From the repository root in PowerShell:

```powershell
$items = @(
  '.github/workflows/package.yml',
  '.github/workflows/release-please.yml',
  '.github/workflows/commitlint.yml',
  '.release-please-config.json',
  '.release-please-manifest.json',
  'commitlint.config.cjs',
  'WorkflowKit.md'
)

Compress-Archive -Path $items -DestinationPath workflow-kit.zip -Force
```

Unzip `workflow-kit.zip` into another repo root, adjust the `env` values in `nuget-package.yml`, add required secrets/environment, and you should be ready to tag a release.
